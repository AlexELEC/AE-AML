# -*- coding: utf-8 -*-

# SPDX-License-Identifier: GPL-2.0
# Copyright (C) 2011-present Alex@ELEC (http://alexelec.in.ua)

import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon

__author__ = 'AlexELEC'
__scriptid__ = 'script.tvip.start.timer'
__addon__ = xbmcaddon.Addon(id=__scriptid__)
__cwd__ = __addon__.getAddonInfo('path')

def main():
    dlg_timer = xbmcgui.Dialog()
    cnt_timer = dlg_timer.input(heading='TVIP Poweroff timer (min)', defaultt='', type=xbmcgui.INPUT_NUMERIC, autoclose=5000)
    if cnt_timer == '': cnt_timer = '0'
    file = '/tmp/tvip-timer.conf'
    xbmcvfs.delete(file)

    if cnt_timer != '0':
        f = xbmcvfs.File(file, 'w')
        f.write(cnt_timer)
        f.close()

    xbmc.executebuiltin('XBMC.Quit')

if (__name__ == '__main__'):
    main()
